SHRINGAR - CRUD (Backend + Frontend)
-----------------------------------

What I created:
- Backend (Express + Mongoose) at: server/
- Frontend (React + Vite) at: client/

How to run locally:

1) Install and run MongoDB locally (example using mongod):
   - On Linux/Mac: ensure `mongod` is running (default port 27017).
   - On Windows: run MongoDB as a service or via MongoDB Compass.
   - Alternatively, use a MongoDB Atlas connection string and set it in server/.env

2) Backend:
   cd server
   npm install
   # set env var or create .env with MONGO_URI
   # e.g. export MONGO_URI='mongodb://127.0.0.1:27017/shringarDB'
   npm start
   The server will run on port 5000 by default.

3) Frontend:
   cd client
   npm install
   npm run dev
   Open the dev URL shown by Vite (usually http://localhost:5173) and use the UI.

API endpoints:
- GET    /api/jewellery        -> list items
- POST   /api/jewellery        -> create item (body: name, price, description, image)
- GET    /api/jewellery/:id    -> get single item
- PUT    /api/jewellery/:id    -> update item
- DELETE /api/jewellery/:id    -> delete item

Notes:
- If your original project had a frontend folder, I preserved it and added the CRUD client component.
- If you'd like me to merge the UI into a specific file from your original project, tell me which file path (relative to the uploaded zip) and I will attempt to inject the UI there.

Good luck! If anything doesn't run, paste the terminal errors here and I'll fix them.
