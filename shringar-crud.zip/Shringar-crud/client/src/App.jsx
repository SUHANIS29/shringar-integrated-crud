import React, { useEffect, useState } from 'react';
import axios from 'axios';

const API = import.meta.env.VITE_API_URL || 'http://localhost:5000/api/jewellery';

export default function App() {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({ name: '', price: '', description: '', image: '' });
  const [editingId, setEditingId] = useState(null);

  useEffect(() => { loadItems(); }, []);

  const loadItems = async () => {
    try {
      const res = await axios.get(API);
      setItems(res.data);
    } catch (err) {
      console.error(err);
      alert('Could not load items from API. Make sure backend is running.');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingId) {
        await axios.put(`${API}/${editingId}`, { ...form, price: Number(form.price) });
        setEditingId(null);
      } else {
        await axios.post(API, { ...form, price: Number(form.price) });
      }
      setForm({ name: '', price: '', description: '', image: '' });
      loadItems();
    } catch (err) {
      console.error(err);
      alert('Error saving item: ' + (err.response?.data?.error || err.message));
    }
  };

  const startEdit = (item) => {
    setEditingId(item._id);
    setForm({ name: item.name, price: String(item.price), description: item.description || '', image: item.image || '' });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const del = async (id) => {
    if (!confirm('Delete this item?')) return;
    await axios.delete(`${API}/${id}`);
    loadItems();
  };

  return (
    <div style={{ maxWidth: 900, margin: '20px auto', fontFamily: 'Arial, sans-serif' }}>
      <h1>Shringar - Jewellery CRUD</h1>

      <form onSubmit={handleSubmit} style={{ marginBottom: 20, padding: 12, border: '1px solid #ddd', borderRadius: 8 }}>
        <h3>{editingId ? 'Edit Item' : 'Add New Item'}</h3>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
          <input placeholder="Name" value={form.name} onChange={e=>setForm({...form, name: e.target.value})} required />
          <input placeholder="Price" value={form.price} onChange={e=>setForm({...form, price: e.target.value})} required />
          <input placeholder="Image URL (optional)" value={form.image} onChange={e=>setForm({...form, image: e.target.value})} />
          <input placeholder="Description" value={form.description} onChange={e=>setForm({...form, description: e.target.value})} />
        </div>
        <div style={{ marginTop: 10 }}>
          <button type="submit">{editingId ? 'Update' : 'Add'}</button>
          {editingId && <button type="button" onClick={()=>{ setEditingId(null); setForm({ name:'', price:'', description:'', image:'' }) }} style={{ marginLeft: 8 }}>Cancel</button>}
        </div>
      </form>

      <div>
        {items.length === 0 && <div>No items yet. Add one above.</div>}
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {items.map(item => (
            <li key={item._id} style={{ padding: 12, border: '1px solid #eee', marginBottom: 8, borderRadius: 6, display: 'flex', gap: 12 }}>
              <div style={{ width: 80 }}>
                {item.image ? <img src={item.image} alt={item.name} style={{ width: '80px', height: '80px', objectFit: 'cover', borderRadius: 6 }} /> : <div style={{ width:80, height:80, background:'#f4f4f4', display:'flex', alignItems:'center', justifyContent:'center' }}>No image</div>}
              </div>
              <div style={{ flex: 1 }}>
                <strong>{item.name}</strong><br />
                ₹{item.price} <br />
                <small>{item.description}</small>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                <button onClick={() => startEdit(item)}>Edit</button>
                <button onClick={() => del(item._id)}>Delete</button>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
