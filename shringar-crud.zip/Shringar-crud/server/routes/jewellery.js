// const express = require('express');
// const router = express.Router();
// const Jewellery = require('../models/Jewellery');

// // Create
// router.post('/', async (req, res) => {
//   try {
//     const item = await Jewellery.create(req.body);
//     res.status(201).json(item);
//   } catch (err) {
//     res.status(400).json({ error: err.message });
//   }
// });

// // Read all
// router.get('/', async (req, res) => {
//   try {
//     const items = await Jewellery.find().sort({ createdAt: -1 });
//     res.json(items);
//   } catch (err) {
//     res.status(500).json({ error: err.message });
//   }
// });

// // Read one
// router.get('/:id', async (req, res) => {
//   try {
//     const item = await Jewellery.findById(req.params.id);
//     if (!item) return res.status(404).json({ error: 'Not found' });
//     res.json(item);
//   } catch (err) {
//     res.status(500).json({ error: err.message });
//   }
// });

// // Update
// router.put('/:id', async (req, res) => {
//   try {
//     const updated = await Jewellery.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
//     if (!updated) return res.status(404).json({ error: 'Not found' });
//     res.json(updated);
//   } catch (err) {
//     res.status(400).json({ error: err.message });
//   }
// });

// // Delete
// router.delete('/:id', async (req, res) => {
//   try {
//     await Jewellery.findByIdAndDelete(req.params.id);
//     res.json({ message: 'Deleted' });
//   } catch (err) {
//     res.status(500).json({ error: err.message });
//   }
// });

// module.exports = router;
const express = require('express');
const router = express.Router();
const Jewellery = require('../models/Jewellery');

// Create
router.post('/', async (req, res) => {
  try {
    const item = new Jewellery(req.body);
    await item.save();
    res.json(item);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Read All
router.get('/', async (req, res) => {
  const items = await Jewellery.find();
  res.json(items);
});

// Update
router.put('/:id', async (req, res) => {
  const updated = await Jewellery.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(updated);
});

// Delete
router.delete('/:id', async (req, res) => {
  await Jewellery.findByIdAndDelete(req.params.id);
  res.json({ message: 'Deleted' });
});

module.exports = router;
