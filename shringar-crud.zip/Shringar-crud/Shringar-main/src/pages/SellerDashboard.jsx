import React from "react";

function SellerDashboard() {
  return <h2>Seller Dashboard (dummy page)</h2>;
}

export default SellerDashboard;
